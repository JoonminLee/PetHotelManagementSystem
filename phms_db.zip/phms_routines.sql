CREATE DATABASE  IF NOT EXISTS `phms` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `phms`;
-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: phms
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `reroomsize`
--

DROP TABLE IF EXISTS `reroomsize`;
/*!50001 DROP VIEW IF EXISTS `reroomsize`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `reroomsize` AS SELECT 
 1 AS `re_num`,
 1 AS `re_id`,
 1 AS `re_phone`,
 1 AS `re_s_num`,
 1 AS `re_r_num`,
 1 AS `re_check_in`,
 1 AS `re_check_out`,
 1 AS `re_day`,
 1 AS `s_num`,
 1 AS `s_size`,
 1 AS `s_r_price`,
 1 AS `s_w_price`,
 1 AS `r_num`,
 1 AS `r_s_num`,
 1 AS `r_status`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `visitorroomsize`
--

DROP TABLE IF EXISTS `visitorroomsize`;
/*!50001 DROP VIEW IF EXISTS `visitorroomsize`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `visitorroomsize` AS SELECT 
 1 AS `v_num`,
 1 AS `v_id`,
 1 AS `v_name`,
 1 AS `v_email`,
 1 AS `v_from`,
 1 AS `v_room`,
 1 AS `r_num`,
 1 AS `r_s_num`,
 1 AS `r_status`,
 1 AS `s_num`,
 1 AS `s_size`,
 1 AS `s_r_price`,
 1 AS `s_w_price`,
 1 AS `re_num`,
 1 AS `re_id`,
 1 AS `re_phone`,
 1 AS `re_s_num`,
 1 AS `re_r_num`,
 1 AS `re_check_in`,
 1 AS `re_check_out`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `userroomsize`
--

DROP TABLE IF EXISTS `userroomsize`;
/*!50001 DROP VIEW IF EXISTS `userroomsize`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `userroomsize` AS SELECT 
 1 AS `u_num`,
 1 AS `u_id`,
 1 AS `u_pwd`,
 1 AS `u_name`,
 1 AS `u_gender`,
 1 AS `u_phone`,
 1 AS `u_email`,
 1 AS `u_birth`,
 1 AS `u_r_num`,
 1 AS `r_num`,
 1 AS `r_s_num`,
 1 AS `r_status`,
 1 AS `s_num`,
 1 AS `s_size`,
 1 AS `s_r_price`,
 1 AS `s_w_price`,
 1 AS `re_num`,
 1 AS `re_id`,
 1 AS `re_phone`,
 1 AS `re_s_num`,
 1 AS `re_r_num`,
 1 AS `re_check_in`,
 1 AS `re_check_out`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `roomsizedto`
--

DROP TABLE IF EXISTS `roomsizedto`;
/*!50001 DROP VIEW IF EXISTS `roomsizedto`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `roomsizedto` AS SELECT 
 1 AS `r_num`,
 1 AS `r_s_num`,
 1 AS `r_status`,
 1 AS `s_num`,
 1 AS `s_size`,
 1 AS `s_r_price`,
 1 AS `s_w_price`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `reroomsize`
--

/*!50001 DROP VIEW IF EXISTS `reroomsize`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `reroomsize` AS select `aa`.`re_num` AS `re_num`,`aa`.`re_id` AS `re_id`,`aa`.`re_phone` AS `re_phone`,`aa`.`re_s_num` AS `re_s_num`,`aa`.`re_r_num` AS `re_r_num`,`aa`.`re_check_in` AS `re_check_in`,`aa`.`re_check_out` AS `re_check_out`,`aa`.`re_day` AS `re_day`,`aa`.`s_num` AS `s_num`,`aa`.`s_size` AS `s_size`,`aa`.`s_r_price` AS `s_r_price`,`aa`.`s_w_price` AS `s_w_price`,`room`.`r_num` AS `r_num`,`room`.`r_s_num` AS `r_s_num`,`room`.`r_status` AS `r_status` from ((select `reservation`.`re_num` AS `re_num`,`reservation`.`re_id` AS `re_id`,`reservation`.`re_phone` AS `re_phone`,`reservation`.`re_s_num` AS `re_s_num`,`reservation`.`re_r_num` AS `re_r_num`,`reservation`.`re_check_in` AS `re_check_in`,`reservation`.`re_check_out` AS `re_check_out`,`reservation`.`re_day` AS `re_day`,`size`.`s_num` AS `s_num`,`size`.`s_size` AS `s_size`,`size`.`s_r_price` AS `s_r_price`,`size`.`s_w_price` AS `s_w_price` from (`reservation` join `size`) where (`reservation`.`re_s_num` = `size`.`s_num`)) `aa` join `room`) where (`aa`.`re_r_num` = `room`.`r_num`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `visitorroomsize`
--

/*!50001 DROP VIEW IF EXISTS `visitorroomsize`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `visitorroomsize` AS select `bb`.`v_num` AS `v_num`,`bb`.`v_id` AS `v_id`,`bb`.`v_name` AS `v_name`,`bb`.`v_email` AS `v_email`,`bb`.`v_from` AS `v_from`,`bb`.`v_room` AS `v_room`,`bb`.`r_num` AS `r_num`,`bb`.`r_s_num` AS `r_s_num`,`bb`.`r_status` AS `r_status`,`bb`.`s_num` AS `s_num`,`bb`.`s_size` AS `s_size`,`bb`.`s_r_price` AS `s_r_price`,`bb`.`s_w_price` AS `s_w_price`,`reservation`.`re_num` AS `re_num`,`reservation`.`re_id` AS `re_id`,`reservation`.`re_phone` AS `re_phone`,`reservation`.`re_s_num` AS `re_s_num`,`reservation`.`re_r_num` AS `re_r_num`,`reservation`.`re_check_in` AS `re_check_in`,`reservation`.`re_check_out` AS `re_check_out` from ((select `aa`.`v_num` AS `v_num`,`aa`.`v_id` AS `v_id`,`aa`.`v_name` AS `v_name`,`aa`.`v_email` AS `v_email`,`aa`.`v_from` AS `v_from`,`aa`.`v_room` AS `v_room`,`aa`.`r_num` AS `r_num`,`aa`.`r_s_num` AS `r_s_num`,`aa`.`r_status` AS `r_status`,`size`.`s_num` AS `s_num`,`size`.`s_size` AS `s_size`,`size`.`s_r_price` AS `s_r_price`,`size`.`s_w_price` AS `s_w_price` from ((select `visitor`.`v_num` AS `v_num`,`visitor`.`v_id` AS `v_id`,`visitor`.`v_name` AS `v_name`,`visitor`.`v_email` AS `v_email`,`visitor`.`v_from` AS `v_from`,`visitor`.`v_room` AS `v_room`,`room`.`r_num` AS `r_num`,`room`.`r_s_num` AS `r_s_num`,`room`.`r_status` AS `r_status` from (`visitor` join `room`) where (`visitor`.`v_room` = `room`.`r_num`)) `aa` join `size`) where (`aa`.`r_s_num` = `size`.`s_num`)) `bb` join `reservation`) where (`bb`.`v_id` = `reservation`.`re_id`) limit 0,1000 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `userroomsize`
--

/*!50001 DROP VIEW IF EXISTS `userroomsize`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `userroomsize` AS select `bb`.`u_num` AS `u_num`,`bb`.`u_id` AS `u_id`,`bb`.`u_pwd` AS `u_pwd`,`bb`.`u_name` AS `u_name`,`bb`.`u_gender` AS `u_gender`,`bb`.`u_phone` AS `u_phone`,`bb`.`u_email` AS `u_email`,`bb`.`u_birth` AS `u_birth`,`bb`.`u_r_num` AS `u_r_num`,`bb`.`r_num` AS `r_num`,`bb`.`r_s_num` AS `r_s_num`,`bb`.`r_status` AS `r_status`,`bb`.`s_num` AS `s_num`,`bb`.`s_size` AS `s_size`,`bb`.`s_r_price` AS `s_r_price`,`bb`.`s_w_price` AS `s_w_price`,`reservation`.`re_num` AS `re_num`,`reservation`.`re_id` AS `re_id`,`reservation`.`re_phone` AS `re_phone`,`reservation`.`re_s_num` AS `re_s_num`,`reservation`.`re_r_num` AS `re_r_num`,`reservation`.`re_check_in` AS `re_check_in`,`reservation`.`re_check_out` AS `re_check_out` from ((select `aa`.`u_num` AS `u_num`,`aa`.`u_id` AS `u_id`,`aa`.`u_pwd` AS `u_pwd`,`aa`.`u_name` AS `u_name`,`aa`.`u_gender` AS `u_gender`,`aa`.`u_phone` AS `u_phone`,`aa`.`u_email` AS `u_email`,`aa`.`u_birth` AS `u_birth`,`aa`.`u_r_num` AS `u_r_num`,`aa`.`r_num` AS `r_num`,`aa`.`r_s_num` AS `r_s_num`,`aa`.`r_status` AS `r_status`,`size`.`s_num` AS `s_num`,`size`.`s_size` AS `s_size`,`size`.`s_r_price` AS `s_r_price`,`size`.`s_w_price` AS `s_w_price` from ((select `user`.`u_num` AS `u_num`,`user`.`u_id` AS `u_id`,`user`.`u_pwd` AS `u_pwd`,`user`.`u_name` AS `u_name`,`user`.`u_gender` AS `u_gender`,`user`.`u_phone` AS `u_phone`,`user`.`u_email` AS `u_email`,`user`.`u_birth` AS `u_birth`,`user`.`u_r_num` AS `u_r_num`,`room`.`r_num` AS `r_num`,`room`.`r_s_num` AS `r_s_num`,`room`.`r_status` AS `r_status` from (`user` join `room`) where (`user`.`u_r_num` = `room`.`r_num`)) `aa` join `size`) where (`aa`.`r_s_num` = `size`.`s_num`)) `bb` join `reservation`) where (`bb`.`u_id` = `reservation`.`re_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `roomsizedto`
--

/*!50001 DROP VIEW IF EXISTS `roomsizedto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `roomsizedto` AS select `room`.`r_num` AS `r_num`,`room`.`r_s_num` AS `r_s_num`,`room`.`r_status` AS `r_status`,`size`.`s_num` AS `s_num`,`size`.`s_size` AS `s_size`,`size`.`s_r_price` AS `s_r_price`,`size`.`s_w_price` AS `s_w_price` from (`room` join `size`) where ((`room`.`r_status` = 0) and (`room`.`r_s_num` = `size`.`s_num`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-18 14:36:34
